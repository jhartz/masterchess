MasterChess Icons
=================

* `Chess-*.png, Chess.icns, Chess.ico` - http://www.iconarchive.com/show/mac-icons-by-artua/Chess-icon.html (non-commercial use only)
* `Chess.jpg` - http://abstract.desktopnexus.com/wallpaper/106990/
* `match-new.png` - https://launchpad.net/elementaryicons (GNU GPL v2)
* `pie.png, players.png` - http://wefunction.com/2008/07/function-free-icon-set (attribution required)